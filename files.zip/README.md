# Welcher Artikel telegram bot
This telegram bot will recive a word and send you back information about it using web site der-artikel.de